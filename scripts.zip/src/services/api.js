const API_BASE_URL = 'https://tanova-backend.onrender.com/api/v1'

async function request(endpoint, options = {}) {
  const method = (options.method || 'GET').toUpperCase()
  const headers = {}

  // Hanya tambahkan Content-Type jika ada body (mencegah error pada DELETE)
  if (options.body) {
    headers['Content-Type'] = 'application/json'
  }

  if (options.headers) {
    Object.assign(headers, options.headers)
  }

  const token = localStorage.getItem('tanova_token')
  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  const config = {
    ...options,
    headers,
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config)

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(
        errorData.message || errorData.detail || `Terjadi kesalahan server: ${response.status}`,
      )
    }

    if (response.status === 204) {
      return null
    }

    return await response.json()
  } catch (error) {
    console.error('API Request Error:', error)
    throw error
  }
}

export const api = {
  // Auth
  async login(credentials) {
    return request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    })
  },

  async refreshToken(refreshToken) {
    return request('/auth/refresh', {
      method: 'POST',
      body: JSON.stringify({ refresh_token: refreshToken }),
    })
  },

  // Users & Profile
  async getMe() {
    return request('/users/me')
  },

  async getUsers() {
    return request('/users')
  },

  async createUser(userData) {
    return request('/users', {
      method: 'POST',
      body: JSON.stringify(userData),
    })
  },

  async patchUser(id, userData) {
    return request(`/users/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(userData),
    })
  },

  async updateUser(id, userData) {
    return this.patchUser(id, userData)
  },

  async resetUserPassword(id, passwordData) {
    return request(`/users/${id}/password`, {
      method: 'PUT',
      body: JSON.stringify(passwordData),
    })
  },

  async deleteUser(id) {
    return request(`/users/${id}`, {
      method: 'DELETE',
    })
  },

  async assignUserGreenhouses(id, greenhouseIds) {
    return request(`/users/${id}/greenhouses`, {
      method: 'PUT',
      body: JSON.stringify({ greenhouse_ids: greenhouseIds }),
    })
  },

  // Greenhouses
  async getGreenhouses() {
    return request('/greenhouses')
  },

  async createGreenhouse(data) {
    return request('/greenhouses', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  },

  async patchGreenhouse(id, greenhouseData) {
    return request(`/greenhouses/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(greenhouseData),
    })
  },

  async deleteGreenhouse(id) {
    return request(`/greenhouses/${id}`, {
      method: 'DELETE',
    })
  },

  // Devices
  // Devices & Dashboard (Gunakan helper 'request', bukan axios)
  async getDevices() {
    return request('/devices')
  },

  async addDevice(deviceData) {
    return request('/devices', {
      method: 'POST',
      body: JSON.stringify(deviceData),
    })
  },

  async getDeviceTelemetry(id) {
    return request(`/devices/${id}/telemetry`)
  },

  async patchDevice(id, deviceData) {
    return request(`/devices/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(deviceData),
    })
  },

  async deleteDevice(id) {
    return request(`/devices/${id}`, {
      method: 'DELETE',
    })
  },

  // Endpoint overview yang wajib membawa device_id
  async getDashboardOverview(deviceId) {
    const url = deviceId ? `/dashboard/overview?device_id=${deviceId}` : '/dashboard/overview'
    return request(url)
  },
}