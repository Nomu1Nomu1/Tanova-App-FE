<script setup>
import { ref, computed, onMounted } from 'vue'
import { api } from '../services/api'

const searchQuery = ref('')
const selectedStatus = ref('Semua Status')

const devicesList = ref([])
const selectedDevice = ref(null)
const overviewData = ref(null)
const loading = ref(false)

// 1. Ambil daftar perangkat nyata dari backend (/devices)
async function loadDevices() {
  loading.value = true
  try {
    const response = await api.getDevices()
    devicesList.value = Array.isArray(response) ? response : response.data || []

    if (devicesList.value.length > 0) {
      const currentId = selectedDevice.value?.id || selectedDevice.value?._id
      const target = devicesList.value.find(d => (d.id || d._id) === currentId) || devicesList.value[0]
      await selectDevice(target)
    }
  } catch (error) {
    console.error('Gagal memuat perangkat:', error)
  } finally {
    loading.value = false
  }
}

// 2. Ambil data overview / metrik terkini dari endpoint /dashboard/overview backend
async function fetchOverview(deviceId) {
  if (!deviceId) return
  try {
    const res = await api.getDashboardOverview(deviceId)
    console.log('DEBUG MENTAH DARI BACKEND:', res) // Buka F12 Console untuk melihat isinya
    
    // Simpan seluruh respons agar dapat diurai fleksibel
    overviewData.value = res || {}
  } catch (error) {
    console.warn('Gagal memuat overview metrik:', error.message)
    overviewData.value = null
  }
}

// 3. Saat perangkat diklik dari tabel (Hanya dideklarasikan sekali di sini)
async function selectDevice(dev) {
  selectedDevice.value = dev
  const deviceId = dev.id || dev._id
  await fetchOverview(deviceId)
}

onMounted(() => {
  loadDevices()
})

// 4. Sensor dinamis murni dari konfigurasi perangkat dan overview backend
// Sensor dinamis murni dari konfigurasi perangkat dan overview backend
// 4. Sensor dinamis murni dengan pemetaan key langsung dari root ataupun sub-objek
const sensors = computed(() => {
  if (!selectedDevice.value) return []

  const deviceSensors = selectedDevice.value.sensors || []
  
  // Ambil objek metrik dari berbagai kemungkinan struktur backend
  const res = overviewData.value || {}
  const metrics = res.metrics || res.data || res.telemetry || res

  if (deviceSensors.length > 0) {
    return deviceSensors.map(s => {
      let rawVal = null

      // Pencarian berdasarkan tipe sensor atau tb_key yang dikirim database
      if (s.type === 'air_temp') {
        rawVal = metrics.air_temp ?? metrics.temp_air ?? metrics.suhu_udara ?? metrics.temperature_air ?? metrics[s.tb_key]
      } else if (s.type === 'humidity') {
        rawVal = metrics.humidity ?? metrics.hum ?? metrics.kelembapan ?? metrics[s.tb_key]
      } else if (s.type === 'water_temp') {
        rawVal = metrics.water_temp ?? metrics.temp_water ?? metrics.suhu_air ?? metrics[s.tb_key]
      } else if (s.type === 'ph') {
        rawVal = metrics.ph ?? metrics.pH ?? metrics.ph_value ?? metrics[s.tb_key]
      } else if (s.type === 'ec' || s.type === 'tds') {
        rawVal = metrics.ec ?? metrics.tds ?? metrics.ec_value ?? metrics[s.tb_key]
      } else if (s.type === 'waterflow') {
        rawVal = metrics.waterflow ?? metrics.water_flow ?? metrics[s.tb_key]
      } else {
        rawVal = metrics[s.type] ?? metrics[s.tb_key] ?? s.value
      }

      // Ekstraksi jika nilainya berupa objek dari ThingsBoard/backend (misal: { value: 28.5 })
      let finalVal = rawVal
      if (rawVal !== null && typeof rawVal === 'object') {
        finalVal = rawVal.value ?? rawVal.val ?? rawVal.reading ?? '-'
      }

      return {
        id: s.id || s._id,
        name: s.name || s.type.toUpperCase(),
        desc: `Tipe: ${s.type} · Key: ${s.tb_key || '-'}`,
        unit: s.unit || '',
        value: finalVal !== undefined && finalVal !== null && finalVal !== '-' && finalVal !== '' ? `${finalVal} ${s.unit || ''}`.trim() : '-',
        status: s.is_active ? 'Aktif' : 'Nonaktif',
        calibration: s.last_calibrated || '-',
        nextCal: s.next_due_at || '-',
        urgent: Boolean(s.needs_calibration)
      }
    })
  }

  return []
})

// 5. Status aktuator / pompa nyata dari backend
const pumpStatus = computed(() => {
  const actuators = selectedDevice.value?.actuators || []
  const pumpActuator = actuators.find(a => a.type === 'pump' || a.name?.toLowerCase().includes('pompa'))
  
  if (pumpActuator) {
    return pumpActuator.state === 'on' || pumpActuator.is_active ? 'Menyala' : 'Mati'
  }
  
  const p = overviewData.value?.pump ?? overviewData.value?.water_pump
  if (p === true || p === 'on') return 'Menyala'
  if (p === false || p === 'off') return 'Mati'
  return selectedDevice.value?.mode === 'auto' ? 'Otomatis' : 'Mati'
})

const filteredDevices = computed(() => {
  return devicesList.value.filter((dev) => {
    const nameMatch = dev.name?.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
                      (dev.tb_device_id || '').toLowerCase().includes(searchQuery.value.toLowerCase())
    const statusVal = dev.status || 'Terhubung'
    const statusMatch = selectedStatus.value === 'Semua Status' || statusVal === selectedStatus.value
    return nameMatch && statusMatch
  })
})

const totalDevicesCount = computed(() => devicesList.value.length)
const connectedDevicesCount = computed(() => devicesList.value.filter(d => (d.status || 'Terhubung') === 'Terhubung').length)
const disconnectedDevicesCount = computed(() => totalDevicesCount.value - connectedDevicesCount.value)

async function handleRefresh() {
  await loadDevices()
  if (selectedDevice.value) {
    await fetchOverview(selectedDevice.value.id || selectedDevice.value._id)
  }
}

function handleAddDevice() {
  alert('Pengelolaan dan penambahan perangkat dilakukan melalui Panel Administrator.')
}

async function handleCalibrate() {
  if (!selectedDevice.value) {
    alert('Pilih perangkat terlebih dahulu.')
    return
  }
  alert(`Memulai proses kalibrasi untuk perangkat: ${selectedDevice.value.name}`)
}
</script>

<template>
  <div class="tanova-device-container">
    <!-- Top Header Bar -->
    <div class="top-header">
      <div class="brand-box">
        <div class="brand-icon"><i class="fa-solid fa-seedling"></i></div>
        <span class="brand-title">Tanova</span>
      </div>
      <div class="top-actions">
        <button class="icon-btn-top" title="Notifikasi"><i class="fa-solid fa-bell"></i></button>
        <div class="profile-avatar-top">BS</div>
      </div>
    </div>

    <!-- Header Section -->
    <div class="header-section">
      <div>
        <h1 class="page-title">Pengelolaan Perangkat</h1>
        <p class="page-subtitle">
          Pantau koneksi, kelola sensor, dan jaga akurasi pengukuran hidroponik Anda.
        </p>
      </div>
      <div class="header-buttons">
        <button @click="handleRefresh" class="btn-secondary">
          <i class="fa-solid fa-rotate"></i> Segarkan
        </button>
        <button @click="handleAddDevice" class="btn-primary">
          <i class="fa-solid fa-plus"></i> Tambah Perangkat
        </button>
      </div>
    </div>

    <!-- 4 Metric Cards Grid -->
    <div class="metrics-grid">
      <div class="metric-card">
        <div>
          <span class="metric-label">Total Perangkat</span>
          <div class="metric-value">{{ totalDevicesCount }}</div>
          <span class="metric-sub">terdaftar di sistem</span>
        </div>
        <div class="metric-icon-box green-light"><i class="fa-solid fa-hard-drive"></i></div>
      </div>

      <div class="metric-card">
        <div>
          <span class="metric-label">Perangkat Terhubung</span>
          <div class="metric-value">{{ connectedDevicesCount }}</div>
          <span class="metric-sub text-danger">{{ disconnectedDevicesCount }} terputus</span>
        </div>
        <div class="metric-icon-box green-light"><i class="fa-solid fa-wifi"></i></div>
      </div>

      <div class="metric-card">
        <div>
          <span class="metric-label">Sensor Aktif</span>
          <div class="metric-value">{{ sensors.length }}</div>
          <span class="metric-sub">terdeteksi di perangkat</span>
        </div>
        <div class="metric-icon-box green-light"><i class="fa-solid fa-wave-square"></i></div>
      </div>

      <div class="metric-card">
        <div>
          <span class="metric-label">Mode Sistem</span>
          <div
            class="metric-value"
            style="font-size: 18px; margin-top: 4px; text-transform: uppercase"
          >
            {{ selectedDevice?.mode || 'Auto' }}
          </div>
          <span class="metric-sub text-warning">pengaturan aktif</span>
        </div>
        <div class="metric-icon-box green-light"><i class="fa-solid fa-sliders"></i></div>
      </div>
    </div>

    <!-- Daftar Perangkat Section -->
    <div class="card-section mb-24">
      <div class="table-header-row">
        <div class="table-title-group">
          <h3 class="section-title">Daftar Perangkat</h3>
          <span class="badge-count">{{ filteredDevices.length }} perangkat</span>
        </div>
        <div class="table-filter-group">
          <div class="search-box">
            <i class="fa-solid fa-magnifying-glass search-icon-fa"></i>
            <input
              v-model="searchQuery"
              type="text"
              placeholder="Cari nama atau ID"
              class="search-input"
            />
          </div>
          <select v-model="selectedStatus" class="filter-select">
            <option>Semua Status</option>
            <option>Terhubung</option>
            <option>Terputus</option>
          </select>
        </div>
      </div>

      <div class="table-wrapper">
        <table class="custom-table">
          <thead>
            <tr>
              <th>NAMA PERANGKAT</th>
              <th>THINGSBOARD ID</th>
              <th>GREENHOUSE</th>
              <th>KONEKSI</th>
              <th>SENSOR</th>
              <th class="text-right">TINDAKAN</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="loading">
              <td colspan="6" style="text-align: center; padding: 20px; color: #666">
                Memuat perangkat...
              </td>
            </tr>
            <tr v-else-if="filteredDevices.length === 0">
              <td colspan="6" style="text-align: center; padding: 20px; color: #666">
                Tidak ada perangkat ditemukan.
              </td>
            </tr>
            <tr
              v-for="dev in filteredDevices"
              :key="dev.id || dev._id"
              @click="selectDevice(dev)"
              :class="{
                'row-highlight':
                  (selectedDevice?.id || selectedDevice?._id) === (dev.id || dev._id),
              }"
              style="cursor: pointer"
            >
              <td>
                <div class="device-name-cell">
                  <div class="dev-icon-box"><i class="fa-solid fa-server"></i></div>
                  <div>
                    <div class="dev-main-text">{{ dev.name }}</div>
                    <div class="dev-sub-text">
                      ID: <code>{{ dev.id || dev._id }}</code>
                    </div>
                  </div>
                </div>
              </td>
              <td>
                <code>{{ dev.tb_device_id || '-' }}</code>
              </td>
              <td>{{ dev.greenhouse?.name || dev.greenhouse_name || 'Zona Utama' }}</td>
              <td>
                <span
                  :class="[
                    'status-pill',
                    (dev.status || 'Terhubung') === 'Terhubung'
                      ? 'status-connected'
                      : 'status-disconnected',
                  ]"
                >
                  ● {{ dev.status || 'Terhubung' }}
                </span>
              </td>
              <td>{{ dev.sensors?.length || 0 }} aktif</td>
              <td class="text-right">
                <button class="action-icon-btn"><i class="fa-solid fa-gear"></i></button>
                <i class="fa-solid fa-chevron-right arrow-right"></i>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Bottom Split Grid -->
    <div class="bottom-split-grid">
      <!-- Kiri: Sensor & Aktuator -->
      <div class="card-section">
        <div class="sensor-header-row">
          <div>
            <h3 class="section-title">Sensor & Aktuator</h3>
            <p class="section-desc">
              {{ selectedDevice?.name || 'Pilih perangkat' }} · {{ sensors.length }} sensor
              terhubung
            </p>
          </div>
          <span class="badge-otomatis">● Mode: {{ selectedDevice?.mode || 'auto' }}</span>
        </div>

        <div class="table-wrapper mb-16">
          <table class="custom-table sensor-table">
            <thead>
              <tr>
                <th>SENSOR</th>
                <th>PEMBACAAN</th>
                <th>STATUS</th>
                <th>KALIBRASI TERAKHIR</th>
                <th class="text-right">TINDAKAN</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="sensors.length === 0">
                <td colspan="5" style="text-align: center; color: #777; padding: 15px">
                  Belum ada sensor terdaftar pada perangkat ini.
                </td>
              </tr>
              <tr v-for="(sensor, idx) in sensors" :key="idx">
                <td>
                  <div class="sensor-name-cell">
                    <div class="sensor-dot-icon"></div>
                    <div>
                      <div class="dev-main-text">{{ sensor.name }}</div>
                      <div class="dev-sub-text">{{ sensor.desc }}</div>
                    </div>
                  </div>
                </td>
                <td>
                  <span class="sensor-value-bold">{{ sensor.value }}</span>
                </td>
                <td>
                  <span class="status-pill status-connected">● {{ sensor.status }}</span>
                </td>
                <td>
                  <div class="cal-date-text">{{ sensor.calibration }}</div>
                  <div class="cal-next-text">{{ sensor.nextCal }}</div>
                </td>
                <td class="text-right"><button class="btn-atur">Atur</button></td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Aktuator Pompa Air Bar -->
        <div class="actuator-bar">
          <div class="actuator-left">
            <i class="fa-solid fa-bolt pump-icon-fa"></i>
            <span class="actuator-text"
              ><strong>Aktuator / Pompa</strong> Status terkini dari sistem</span
            >
          </div>
          <span class="badge-menyala">● {{ pumpStatus }}</span>
        </div>
      </div>

      <!-- Kanan: Kalibrasi & Info -->
      <div class="card-section">
        <h3 class="section-title calibration-title">Kalibrasi & Kontrol</h3>

        <button @click="handleCalibrate" class="btn-primary full-width mb-24">
          <i class="fa-solid fa-bolt"></i> Mulai Kalibrasi Sensor
        </button>

        <div class="history-header">
          <span class="history-title-label">Informasi Perangkat</span>
        </div>
        <div class="history-footer-note" style="margin-top: 8px">
          <span class="info-circle-sm">i</span> Zona: {{ selectedDevice?.zone || '-' }}<br />
          Catatan: {{ selectedDevice?.notes || 'Tidak ada catatan khusus.' }}
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.tanova-device-container {
  padding: 30px;
  font-family: sans-serif;
  background: #f8faf6;
  min-height: 100vh;
  box-sizing: border-box;
}
.top-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #fff;
  border: 1px solid #e0e0e0;
  padding: 12px 24px;
  border-radius: 12px;
  margin-bottom: 24px;
}
.brand-box {
  display: flex;
  align-items: center;
  gap: 12px;
}
.brand-icon {
  width: 36px;
  height: 36px;
  background: #93ba39;
  color: #fff;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
}
.brand-title {
  font-size: 18px;
  font-weight: bold;
  color: #222;
}
.top-actions {
  display: flex;
  align-items: center;
  gap: 16px;
}
.icon-btn-top {
  width: 36px;
  height: 36px;
  background: #f5f5f5;
  border: 1px solid #ddd;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: #555;
}
.profile-avatar-top {
  width: 36px;
  height: 36px;
  background: #e5f2cc;
  color: #93ba39;
  font-weight: bold;
  font-size: 13px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.header-section {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: bold;
  color: #111;
  margin: 0 0 4px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #666;
  margin: 0;
}
.header-buttons {
  display: flex;
  gap: 12px;
}
.btn-secondary {
  padding: 10px 18px;
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  color: #333;
  display: flex;
  align-items: center;
  gap: 8px;
}
.btn-secondary:hover {
  background: #f5f5f5;
}
.btn-primary {
  padding: 10px 20px;
  background: #93ba39;
  color: #fff;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
}
.btn-primary:hover {
  background: #82a532;
}
.full-width {
  width: 100%;
  justify-content: center;
}
.metrics-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 24px;
}
.metric-card {
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  padding: 20px;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
}
.metric-label {
  font-size: 13px;
  color: #666;
  display: block;
  margin-bottom: 6px;
}
.metric-value {
  font-size: 24px;
  font-weight: bold;
  color: #111;
  margin-bottom: 2px;
}
.metric-sub {
  font-size: 12px;
  color: #555;
}
.text-danger {
  color: #d9534f;
  font-weight: 500;
}
.text-warning {
  color: #f0ad4e;
  font-weight: 500;
}
.metric-icon-box {
  width: 36px;
  height: 36px;
  background: #e5f2cc;
  color: #93ba39;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;
}
.card-section {
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  padding: 24px;
}
.mb-24 {
  margin-bottom: 24px;
}
.mb-16 {
  margin-bottom: 16px;
}
.table-header-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.table-title-group {
  display: flex;
  align-items: center;
  gap: 12px;
}
.section-title {
  font-size: 16px;
  font-weight: bold;
  color: #111;
  margin: 0;
}
.section-desc {
  font-size: 13px;
  color: #666;
  margin: 2px 0 0 0;
}
.calibration-title {
  margin-bottom: 16px !important;
}
.badge-count {
  background: #f1f5ee;
  color: #555;
  font-size: 12px;
  padding: 2px 10px;
  border-radius: 12px;
  font-weight: 500;
}
.table-filter-group {
  display: flex;
  gap: 12px;
}
.search-box {
  position: relative;
  display: flex;
  align-items: center;
}
.search-input {
  padding: 8px 12px 8px 32px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 13px;
  width: 220px;
  background: #fff;
}
.search-input:focus {
  border-color: #93ba39;
  outline: none;
}
.search-icon-fa {
  position: absolute;
  left: 10px;
  color: #888;
  font-size: 12px;
}
.filter-select {
  padding: 8px 12px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 13px;
  background: #fff;
  color: #333;
}
.table-wrapper {
  overflow-x: auto;
}
.custom-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
  text-align: left;
}
.custom-table th {
  color: #777;
  font-weight: 600;
  font-size: 11px;
  letter-spacing: 0.5px;
  padding: 10px 12px;
  border-bottom: 1px solid #eee;
  background: #fafafa;
}
.custom-table td {
  padding: 14px 12px;
  border-bottom: 1px solid #f0f0f0;
  vertical-align: middle;
}
.device-name-cell,
.sensor-name-cell {
  display: flex;
  align-items: center;
  gap: 12px;
}
.dev-icon-box {
  width: 36px;
  height: 36px;
  background: #e5f2cc;
  color: #93ba39;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}
.dev-main-text {
  font-weight: bold;
  color: #222;
}
.dev-sub-text {
  font-size: 12px;
  color: #666;
  margin-top: 2px;
}
.text-dark {
  color: #333;
}
.status-pill {
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
  display: inline-block;
}
.status-connected {
  background: #e5f2cc;
  color: #558b2f;
}
.status-disconnected {
  background: #fde8e8;
  color: #d9534f;
}
.text-right {
  text-align: right;
}
.action-icon-btn {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 14px;
  color: #666;
  padding: 4px;
}
.arrow-right {
  color: #aaa;
  font-size: 11px;
  margin-left: 8px;
}
.bottom-split-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 24px;
}
.sensor-header-row {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 16px;
}
.badge-otomatis {
  background: #e5f2cc;
  color: #558b2f;
  font-size: 12px;
  padding: 4px 12px;
  border-radius: 12px;
  font-weight: 500;
}
.sensor-dot-icon {
  width: 8px;
  height: 8px;
  background: #93ba39;
  border-radius: 50%;
}
.sensor-value-bold {
  font-weight: bold;
  color: #111;
}
.cal-date-text {
  font-size: 12px;
  color: #333;
}
.cal-next-text {
  font-size: 11px;
  color: #666;
  margin-top: 1px;
}
.btn-atur {
  padding: 6px 14px;
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 12px;
  cursor: pointer;
  color: #333;
}
.btn-atur:hover {
  background: #f5f5f5;
}
.actuator-bar {
  background: #f4f8ed;
  border: 1px solid #d4edda;
  padding: 14px 16px;
  border-radius: 8px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.actuator-left {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 13px;
  color: #333;
}
.pump-icon-fa {
  color: #93ba39;
}
.badge-menyala {
  background: #e5f2cc;
  color: #558b2f;
  font-size: 12px;
  padding: 4px 10px;
  border-radius: 12px;
  font-weight: 500;
}
.history-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.history-title-label {
  font-size: 13px;
  font-weight: bold;
  color: #333;
}
.history-footer-note {
  font-size: 11px;
  color: #666;
  line-height: 1.4;
}
.info-circle-sm {
  width: 12px;
  height: 12px;
  background: #ccc;
  color: #fff;
  border-radius: 50%;
  font-size: 9px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
</style>
